package es.ujaen.git.sm1718_g05_practica1;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
 private String datosvolatiles= "Hola";
    private TextView volatil=null;

    //Crea una instancia de una actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {//Bundle savedInstanceState
        // es donde se reciben los datos almacenados tras un recreado de la actividad
        super.onCreate(savedInstanceState); // Siempre llamar a la superclase primero
        //Añado fragmento
        setContentView(R.layout.activity_main);
        //Antes de autentificar la interfaz de usuario, comprobamos si se está recreando una instancia
        // previamente destruida
        if(savedInstanceState!=null){
            // Restaurar los valores del estado guardado
            datosvolatiles=savedInstanceState.getString("volatil",datosvolatiles);
        }
        //Datos volatiles
        volatil=(TextView) findViewById(R.id.volatil);
        volatil.setText(datosvolatiles);
    }

    //En mainActivity debemos introducir un método con onIcon
    //Este metodo convierte los datos a mayusculas cuando el icono es pulsado
    public void onIcon(View vista){
        datosvolatiles=datosvolatiles.toUpperCase();
        volatil.setText(datosvolatiles);
    }
    ///Metodo que guarda el estado
    @Override
    protected void  onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Se guarda el estado de algunas variables
        outState.putString("volatil",datosvolatiles);
    }


}
