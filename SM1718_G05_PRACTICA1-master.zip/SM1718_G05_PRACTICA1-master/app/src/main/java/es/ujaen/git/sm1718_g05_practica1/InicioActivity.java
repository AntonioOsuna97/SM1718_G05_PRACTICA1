package es.ujaen.git.sm1718_g05_practica1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class InicioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        //Añado fragmento de inicio para que comience con el activity_Inicio
        //Cambiar launcher de activity_main del manifest a un launchar de activity
        setContentView(R.layout.inicio_app);
        //Antes de autentificar la interfaz de usuario, comprobamos si se está recreando una instancia
        // previamente destruida
        if (savedInstanceState != null) {
        }

    }

    //Introducimos un método con onIcon
    //Este metodo nos mostrará el activity_main cuando el icono es pulsado
    //En las propiedades inicio_app en el metodo onclick debemos llamar a este método
    public void onIcon2(View vista){
        //Declaramos una variable nueva de tipo intent
        //intent sirve para invocar componentes, en android entendemos por componentes las activities
        Intent nueva = new Intent(getApplicationContext(), MainActivity.class);
        //getApplication()solo está disponible en la clase Activity y en la clase Service,
        //mientras que getApplicationContext()se declara en la clase Context.
        //Inicia la actividad
        startActivity(nueva);
    }
    }

