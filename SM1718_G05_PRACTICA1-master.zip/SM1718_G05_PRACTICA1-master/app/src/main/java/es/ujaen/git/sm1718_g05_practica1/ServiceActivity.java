package es.ujaen.git.sm1718_g05_practica1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;


public class ServiceActivity extends AppCompatActivity {
    //Static final Indica que una variable, método o clase no se va a modificar
    public static final String PARAM_USER = "param_user";
    public static final String PARAM_PASS = "param_pass";
    public static final String PARAM_CORREO = "param_correo";
    public static final String PARAM_DNI = "param_dni";

    //Creamos una instancia de una actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {//Bundle savedInstanceState
        // es donde se reciben los datos almacenados tras un recreado de la actividad
        super.onCreate(savedInstanceState); // Siempre llamar a la superclase primero
        //Añado fragmento
        setContentView(R.layout.activity_service);

        //getIntent() Deuelve la intencion que inició la actividad
        String user= getIntent().getStringExtra(PARAM_USER);
        String pass= getIntent().getStringExtra(PARAM_PASS);
        String ip= getIntent().getStringExtra(PARAM_CORREO);
        short port= getIntent().getShortExtra(PARAM_DNI,(short)6000);


        TextView title = (TextView) findViewById(R.id.textView);
        //Escribe un mensaje
        title.setText("Hola "+user);

    }

    //Metodo que guarda el estado
    @Override
    protected void  onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
       // outState.putString("volatil",datosvolatiles); Aqui guardaria el dato
    }
}
