package es.ujaen.git.sm1718_g05_practica1;

/**
 * Created by usuario on 04/10/2017.
 */
//Apartado 3
public class ConnectionUserData extends PersonalData {
    protected String connectionIp="127.0.0.1";
    protected short connectionPort=6000;//ponemos port para adecuarlo mas

    //Necesitamos un contructor para utilizar los parametros que necesitemos
    //Constructor
    public ConnectionUserData(String user,String pass,String ip,short port){
        //Llamada al constructor de la clase padre para utilizar los parámetros anteriores
        super(user,pass);
        this.connectionIp=ip;
        this.connectionPort=port;
    }

    public short getConnectionPort() {
        return connectionPort;
    }

    public void setConnectionPort(short connectionPort) {
        this.connectionPort = connectionPort;
    }

    public String getConnectionIp() {
        return connectionIp;
    }

    public void setConnectionIp(String connectionIp) {
        this.connectionIp = connectionIp;
    }
}
