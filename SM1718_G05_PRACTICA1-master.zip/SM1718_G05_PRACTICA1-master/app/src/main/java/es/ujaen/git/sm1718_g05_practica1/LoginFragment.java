package es.ujaen.git.sm1718_g05_practica1;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * Aquí se hace la peticion http, ver seminario de socket en java
 * Para tener copia en github se hace un fork
 * A simple {@link Fragment} subclass.
 * Use the {@link LoginFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LoginFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String ip;
    private int port;

    //constructor vacio
    public LoginFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param ip   Parameter 1.
     * @param port Parameter 2.
     * @return A new instance of fragment LoginFragment.
     */

    // TODO: Rename and change types and number of parameters
    public static LoginFragment newInstance(String ip, int port) {
        LoginFragment fragment = new LoginFragment();//se crea un objeto
        Bundle args = new Bundle();//se crea paquete
        args.putString(ARG_PARAM1, ip);//se mete una cadena,arg param es una constante
        args.putInt(ARG_PARAM2, port);//args.putInt se usaria parea meter un entero
        fragment.setArguments(args);
        return fragment;
    }

    //Método que crea la instancia
    @Override
    public void onCreate(Bundle savedInstanceState) { //metodo que crea la entrada, se le mete un metodo con parametros
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            ip = getArguments().getString(ARG_PARAM1);//guardo en una variable de entrada
            port = getArguments().getInt(ARG_PARAM2);// si fuera int se cambiaria a getInt()
        }
    }

    //metodo que crea la vista
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Con inflate dibuja el layout
        View fragment = inflater.inflate(R.layout.fragment_login, container, false);
        //Apartado5
        //Quiero tener acceso a un objeto boton
        //Hacemos un casting
        Button connect = (Button) fragment.findViewById(R.id.button);
        //Buscar si edidText es el de usuario,ip,port y pass
        final EditText pass = (EditText) fragment.findViewById(R.id.editText_login_pass);//donde esta usuario, se declara final porque no se va a modificar
        final EditText correo = (EditText) fragment.findViewById(R.id.editText_login_correo);
        final EditText DNI = (EditText) fragment.findViewById(R.id.editText_login_dni);
        final EditText user = (EditText) fragment.findViewById(R.id.editText_login_user);

        //vincular un evento a un boton
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s_user = user.getText().toString();
                String s_dni = DNI.getText().toString();
                String s_pass = pass.getText().toString();
                String s_correo = correo.getText().toString();
                short port2 = 0;
                //Capturar excepcion para que no nos de error cuando pulsemos el boton de conectar
                try {
                    port2 = Short.parseShort(s_dni);
                } catch (java.lang.NumberFormatException ex) {
                    port2 = 6000;
                }

                //Creamos un objeto llamado data
                ConnectionUserData data = new ConnectionUserData(s_user, s_pass, s_correo, port2);
                //Cada vez que le das a conectar te saldran estos datos
                Toast.makeText(getContext(), "Hola" + s_user + "" + s_pass + "" + s_correo + "" + s_dni, Toast.LENGTH_LONG).show();
                //Comprobamos que el login es correcto

                TareaAutentica tarea = new TareaAutentica();
                tarea.execute(data);//Creamos tarea

//                Intent nueva = new Intent(getActivity(), ServiceActivity.class);
//                nueva.putExtra(ServiceActivity.PARAM_USER,data.getUser());
//                nueva.putExtra("param_pass",data.getPass());
//                nueva.putExtra("param_ip",data.getConnectionIP());
//                nueva.putExtra("param_port",data.getConnectionPort());
//                startActivity(nueva);


            }
        });
        return fragment;//dibuja el layout
    }

    public class TareaAutentica extends AsyncTask<ConnectionUserData, Void, String> {
        private ConnectionUserData data;

        //Aquí es donde esta la autenticación
        public String doInBackground(ConnectionUserData... param) {//... param puede ser uno o varios paraametros de ese tipo
            //Si hay + de 1 parm. data=param
            //Datos los guardo en un atributo de la clase a la hora de enviar el intel

            if (param != null) {
                if (param.length >= 1)
                    data = param[0];
                //Aquí ponemos la peticion http
                /*try {
                    client = new Socket(InetAddress.getLocalHost(),80);
                    input = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    output = new DataOutputStream(client.getOutputStream());
                    output.write("GET / HTTP/1.1\r\nhost:localhost\r\n\r\n".getBytes());
                    while ((line=input.readLine())!=null) {
                        System.out.println(line);
                    }
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } */
            }
                //Todo proceso auntentificacion
                return "OK";

        }

        //Si result es ok la operacion es correcta y sino otro valor

            //Método que inicia la actividad

        public void onPostExecute(String result) {

            if (result.compareToIgnoreCase("OK") == 0) {
                Intent nueva = new Intent(getActivity(), ServiceActivity.class);//Sepamos resultado tarea
                //Introducimos los datos
                //Constante en user, creada en serviceActivity
                nueva.putExtra(ServiceActivity.PARAM_USER, data.getUser());
                nueva.putExtra("param_pass", data.getPass());
                nueva.putExtra("param_correo", data.getConnectionIp());
                nueva.putExtra("param_dni", data.getConnectionPort());
                //Empieza la actividad y puede leer los parámetros
                startActivity(nueva);
            } else {
                //Si no, nos muestra un error
                Toast.makeText(getContext(), "Error auntentificando a " + data.getUser(), Toast.LENGTH_SHORT);
            }

        }

    }
}




